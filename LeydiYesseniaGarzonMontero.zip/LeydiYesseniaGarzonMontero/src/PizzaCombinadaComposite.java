import java.util.ArrayList;

public class PizzaCombinadaComposite extends Pizza {

    private ArrayList<Pizza> pizzas = new ArrayList();

    public void agreagarPizza (Pizza pizza){
        this.pizzas.add(pizza);
    }

    public void quitarPizza(Pizza pizza){
        this.pizzas.remove(pizza);
    }


    @Override
    public double calcularPrecio() {
        double precioTotal = 0.0;
        for (Pizza pizza : this.pizzas) {
            precioTotal += pizza.calcularPrecio();
        }

        return precioTotal;
    }
}
